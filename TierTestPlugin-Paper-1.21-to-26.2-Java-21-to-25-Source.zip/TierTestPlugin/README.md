# TierTest plugin (Java)

Java source project for Paper-based Minecraft servers. Target compatibility requested: Paper 1.21 through 26.2, Java 21 through 25.

## Important compatibility note
The plugin is written against the Paper 1.21 API and Java 21 bytecode for broad compatibility. Minecraft/Paper releases through 26.2 and Java runtimes 21–25 are not verified by this source bundle; Minecraft version numbers and minimum Java requirements vary by release. Build and test against each exact Paper version you intend to support. A plugin compiled against an older API may work on newer Paper versions when APIs remain compatible, but this is not a guarantee.

## Features
- `/tier queue`: opens the queue GUI; players join/leave.
- Players with `tier.queue` can see queued players and select one for a test.
- `/tier give <player> <tier>`: adds the tier temporarily with LuckPerms.
- `/tier remove <player> <tier>`: removes the temporary tier with LuckPerms.
- Configurable GUI title, duration, and permissions.

## Build
Use Java 21 or later and Gradle in a suitable development environment. Run `gradle build`; output is `build/libs/TierTestPlugin-1.1.0.jar`.

## Install
1. Ensure the server runs a compatible Paper build and LuckPerms is installed.
2. Upload the built JAR to the server's `plugins` folder.
3. Grant permissions, e.g. `lp group tester permission set tier.queue true` and `lp group admin permission set tier.give true`.
4. Restart and test.

## Limitations
- This source project has not been compiled or tested on live servers in this environment.
- Queue/tester assignment data is kept in memory and resets on server restart.
- For maximum compatibility, test on each target Minecraft/Paper version and each supported Java runtime. Do not assume every Paper version in the requested range exists or supports Java 21.
