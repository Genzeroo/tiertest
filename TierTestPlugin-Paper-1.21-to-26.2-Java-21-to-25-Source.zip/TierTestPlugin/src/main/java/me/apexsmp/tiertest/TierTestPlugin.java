package me.apexsmp.tiertest;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.stream.Collectors;

public final class TierTestPlugin extends JavaPlugin implements Listener, TabExecutor {
    private final LinkedHashMap<UUID, String> queue = new LinkedHashMap<>();
    private final Map<UUID, UUID> testerForPlayer = new HashMap<>();
    private final Map<UUID, Map<Integer, UUID>> guiTargets = new HashMap<>();
    private String guiTitle;
    private String duration;
    private String queuePermission;
    private String givePermission;
    private final List<String> tiers = Arrays.asList("LT5","LT4","LT3","LT2","LT1","HT5","HT4","HT3","HT2","HT1");

    @Override public void onEnable() {
        saveDefaultConfig();
        FileConfiguration c = getConfig();
        guiTitle = color(c.getString("gui-title", "&4&lTIER TEST"));
        duration = c.getString("tier-duration", "30d");
        queuePermission = c.getString("permissions.queue", "tier.queue");
        givePermission = c.getString("permissions.manage", "tier.give");
        Objects.requireNonNull(getCommand("tier")).setExecutor(this);
        Objects.requireNonNull(getCommand("tier")).setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("TierTestPlugin enabled.");
    }

    @Override public void onDisable() {
        queue.clear();
        testerForPlayer.clear();
        guiTargets.clear();
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            help(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "queue":
                if (!(sender instanceof Player)) {
                    sender.sendMessage(color("&cOnly players can open the queue."));
                    return true;
                }
                openQueue((Player) sender);
                return true;
            case "give":
            case "remove":
                manageTier(sender, args, args[0].equalsIgnoreCase("give"));
                return true;
            default:
                help(sender);
                return true;
        }
    }

    private void manageTier(CommandSender sender, String[] args, boolean give) {
        if (!sender.hasPermission(givePermission) && !sender.hasPermission("tiertest.admin")) {
            sender.sendMessage(color("&cYou don't have permission to use this command."));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(color("&cUsage: /tier " + (give ? "give" : "remove") + " <player> <tier>"));
            sender.sendMessage(color("&7Available tiers: &f" + String.join(", ", tiers)));
            return;
        }
        String targetName = args[1];
        String tier = args[2].toUpperCase(Locale.ROOT);
        if (!tiers.contains(tier)) {
            sender.sendMessage(color("&cInvalid tier. &7Available: &f" + String.join(", ", tiers)));
            return;
        }
        // Avoid command injection and malformed player names.
        if (!targetName.matches("[A-Za-z0-9_]{1,16}")) {
            sender.sendMessage(color("&cInvalid player name."));
            return;
        }
        String lpCommand = give
                ? "lp user " + targetName + " parent addtemp " + tier + " " + duration
                : "lp user " + targetName + " parent removetemp " + tier;
        boolean accepted = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), lpCommand);
        if (!accepted) {
            sender.sendMessage(color("&cThe LuckPerms command could not be executed. Check that LuckPerms is installed."));
            return;
        }
        sender.sendMessage("");
        sender.sendMessage(color(give ? "&a&lTIER GIVEN" : "&c&lTIER REMOVED"));
        sender.sendMessage(color("&7Player: &f" + targetName));
        sender.sendMessage(color("&7Tier: &f" + tier));
        if (give) sender.sendMessage(color("&7Duration: &f" + duration));
        sender.sendMessage("");
        Player online = Bukkit.getPlayerExact(targetName);
        if (online != null) {
            if (give) {
                online.sendMessage(color("&a&lTIER RECEIVED!"));
                online.sendMessage(color("&7You received the &f" + tier + " &7tier."));
                online.sendMessage(color("&7Duration: &f" + duration));
            } else {
                online.sendMessage(color("&c&lTIER REMOVED!"));
                online.sendMessage(color("&7Your &f" + tier + " &7tier has been removed."));
            }
        }
    }

    private void openQueue(Player player) {
        Inventory inv = Bukkit.createInventory(player, 27, guiTitle);
        ItemStack filler = item(Material.GRAY_STAINED_GLASS_PANE, " ", Collections.emptyList());
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);
        UUID id = player.getUniqueId();
        long queueSize = queue.size();
        inv.setItem(4, item(Material.PAPER, "&b&lTIER TEST QUEUE",
                Arrays.asList("&7Players waiting: &f" + queueSize, "&7", "&eClick the button below to join.")));
        inv.setItem(22, queue.containsKey(id)
                ? item(Material.RED_CONCRETE, "&c&lLEAVE TIER TEST", Arrays.asList("&7Click to leave the queue."))
                : item(Material.LIME_CONCRETE, "&a&lJOIN TIER TEST", Arrays.asList("&7Click to join the queue.")));

        Map<Integer, UUID> targets = new HashMap<>();
        if (player.hasPermission(queuePermission) || player.hasPermission("tiertest.admin")) {
            int slot = 9;
            for (UUID queuedId : queue.keySet()) {
                if (slot > 17) break;
                Player queued = Bukkit.getPlayer(queuedId);
                if (queued == null || queued.getUniqueId().equals(id)) continue;
                inv.setItem(slot, item(Material.PLAYER_HEAD, "&e" + queued.getName(),
                        Arrays.asList("&7Queued for a tier test.", "&7", "&aClick to pick this player.")));
                ItemStack head = inv.getItem(slot);
                if (head != null && head.getItemMeta() instanceof org.bukkit.inventory.meta.SkullMeta) {
                    org.bukkit.inventory.meta.SkullMeta meta = (org.bukkit.inventory.meta.SkullMeta) head.getItemMeta();
                    meta.setOwningPlayer(queued);
                    head.setItemMeta(meta);
                }
                targets.put(slot, queuedId);
                slot++;
            }
        }
        guiTargets.put(id, targets);
        player.openInventory(inv);
    }

    @EventHandler public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (!event.getView().getTitle().equals(guiTitle)) return;
        event.setCancelled(true);
        Player player = (Player) event.getWhoClicked();
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getView().getTopInventory().getSize()) return;

        if (slot == 22) {
            UUID id = player.getUniqueId();
            if (queue.containsKey(id)) {
                queue.remove(id);
                player.sendMessage(color("&cYou left the tier test queue."));
            } else {
                queue.put(id, player.getName());
                player.sendMessage(color("&aYou joined the tier test queue."));
                player.sendMessage(color("&7Wait for a tester to pick you."));
            }
            openQueue(player);
            return;
        }
        if (slot >= 9 && slot <= 17) {
            if (!player.hasPermission(queuePermission) && !player.hasPermission("tiertest.admin")) return;
            UUID targetId = guiTargets.getOrDefault(player.getUniqueId(), Collections.emptyMap()).get(slot);
            if (targetId == null) return;
            Player target = Bukkit.getPlayer(targetId);
            if (target == null || !queue.containsKey(targetId)) {
                player.sendMessage(color("&cThat player is no longer online or queued."));
                openQueue(player);
                return;
            }
            if (target.getUniqueId().equals(player.getUniqueId())) {
                player.sendMessage(color("&cYou cannot pick yourself."));
                return;
            }
            queue.remove(targetId);
            testerForPlayer.put(targetId, player.getUniqueId());
            target.sendMessage(color("&aA tester picked you for a tier test."));
            target.sendMessage(color("&7Type &f/msg " + player.getName() + " &7to contact your tester."));
            player.sendMessage(color("&aYou picked &f" + target.getName() + " &afor the tier test."));
            player.closeInventory();
        }
    }

    @EventHandler public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTitle().equals(guiTitle)) event.setCancelled(true);
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        queue.remove(id);
        testerForPlayer.remove(id);
        guiTargets.remove(id);
        guiTargets.values().forEach(map -> map.values().removeIf(id::equals));
        testerForPlayer.values().removeIf(id::equals);
    }

    private ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            if (!lore.isEmpty()) meta.setLore(lore.stream().map(TierTestPlugin::color).collect(Collectors.toList()));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private static String color(String text) { return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text); }

    private void help(CommandSender sender) {
        sender.sendMessage(color("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(color("&4&l          TIER SYSTEM"));
        sender.sendMessage(color("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        sender.sendMessage(color("&b/tier queue &8» &7Open Tier Test Queue"));
        if (sender.hasPermission(givePermission) || sender.hasPermission("tiertest.admin")) {
            sender.sendMessage(color("&a/tier give <player> <tier> &8» &7Give a tier"));
            sender.sendMessage(color("&c/tier remove <player> <tier> &8» &7Remove a tier"));
        }
        sender.sendMessage(color("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return Arrays.asList("queue", "give", "remove").stream()
                .filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        if (args.length == 3 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("remove"))) {
            return tiers.stream().filter(t -> t.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
}
